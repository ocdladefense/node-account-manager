
export default class Order {

    order = {};

    orderLines = [];
    contactId = null;
    pricebookEntries = null;
    paymentMethodId = null;
    pricebook2Id = null;

    constructor(accountId, contactId) {
        this.orderLines = [];

        this.order = {
            AccountId: accountId,
            EffectiveDate: new Date().toISOString().split('T')[0],
            Status: "Draft",
            Pricebook2Id: null,
            BillToContactId: contactId,
            PostingEntity__c: "Invoice"
        };


    }



    async toObject() {

        if (this.paymentMethodId == "invoice") {
            this.order.PostingEntity__c = "Invoice";
        } else {
            this.order.PostingEntity__c = "Receipt";
        }

        let lines = this.toOrderItems();

        this.order.OrderItems = {
            records: lines.map((line, index) => ({
                attributes: { type: "OrderItem", referenceId: "refItem" + (index + 1) },
                ...line
            }))
        };

        return {
            records: [{ attributes: { type: "Order", referenceId: "refOrder1" }, ...this.order }]
        };
    }


    getStatus() {
        return this.order.Status;
    }

    setPaymentMethod(paymentMethodId) {
        this.paymentMethodId = paymentMethodId;
    }


    setPricebook2Id(standardPricebookId) {
        this.order.Pricebook2Id = standardPricebookId;
    }


    addLines(orderLines) {
        this.orderLines = this.orderLines || [];
        this.orderLines.push(...orderLines);
    }



    setPricebookEntries(pricebookEntries) {
        this.pricebookEntries = pricebookEntries;
    }


    toOrderItems() {

        return this.orderLines.map(line => {
            const pricebookEntry = this.pricebookEntries.get(line.productId);

            return {
                PricebookEntryId: pricebookEntry.Id,
                Quantity: 1,
                UnitPrice: line.UnitPrice,
                Contact__c: line.contactId,
                Description: pricebookEntry.Product2.ClickpdxCatalog__LineDescription__c
            };
        });

    }

    static getOrderDescription(orderLines) {
        const productQuantities = new Map();

        for (const line of orderLines) {
            const quantity = productQuantities.get(line.name) ?? 0;
            productQuantities.set(line.name, quantity + line.quantity);
        }

        const description = [...productQuantities]
            .map(([name, quantity]) => `${quantity} x ${name}`)
            .join(", ")
            .slice(0, 255);

        return description;
    }




    static toAuthNetLineItems(orderLines, APIContracts) {
        const itemList = orderLines.map(line => {
            const item = new APIContracts.LineItemType();

            item.setItemId(line.id);
            item.setName(line.name.slice(0, 31));
            item.setDescription((line.description ?? "").slice(0, 255));
            item.setQuantity(line.quantity);
            item.setUnitPrice(line.unitPrice);

            return item;
        });

        return itemList;
    }


    getLineItems() {
        return Object.values(this.orderLines).map(line => {
            const product = this.pricebookEntries.get(line.productId).Product2;

            return {
                id: line.productId,
                quantity: 1,
                unitPrice: line.UnitPrice,
                name: product.Name,
                description: product.ClickpdxCatalog__LineDescription__c
            };
        })
    }




    extract(prop) {

        let vals = [];

        for (let orderLine of this.orderLines) {
            vals.push(orderLine[prop]);
        }
        return vals;
    }




    isCreditCard() {
        return this.paymentMethodId !== "invoice";
    }


    async getOrderInfo() {
        const soql = `SELECT Id, OrderNumber, TotalAmount FROM Order WHERE Id = '${this.orderId}'`;
        const resp = await client.query(soql);

        return resp.records?.[0];
    }

}



export function hashContactIds(arr) {
    // Join array with a separator to preserve string boundaries
    const combinedString = arr.join('|');
    let hash = 0;

    for (let i = 0; i < combinedString.length; i++) {
        const char = combinedString.charCodeAt(i);
        // Bitwise operations to generate the 32-bit integer hash
        hash = ((hash << 5) - hash) + char;
        hash |= 0; // Convert to a 32-bit integer
    }

    // Return an unsigned 32-bit integer string in base 36 (alphanumeric)
    return (hash >>> 0).toString(36).padStart(7, '0');
}



export function getOrderTotal(orderLines) {
    return Object.values(orderLines).reduce(
        (sum, item) => sum + item.UnitPrice,
        0
    );
}







export async function updateOrderStatus(orderId, response) {
    // For invoices Status will be Activated;
    // For all others, Status will be Posted Payment.

    const updateResp = await client.update("Order", { Id: orderId, Activate__c: true });
    // const updatedOrderResult = await updateResp.json();


    console.log("updateResp:", updateResp.status);

    if (!updateResp.ok) {
        throw new Error(`Failed to update Salesforce Order. Status: ${updateResp.status}`);
    }
}

