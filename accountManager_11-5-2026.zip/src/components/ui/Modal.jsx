import ReactDOM from 'react-dom';
import { React, Children, useState, useEffect, useRef, isValidElement, cloneElement } from 'react';
import Button, { CautionButton, BackButton } from './Button';



export default function Modal({
    isOpen,
    onClose,
    content,
    externalNode,
    children,
    data,
    setData,
}) {

    const containerRef = useRef(null);
    const [currentStep, setCurrentStep] = useState(1);



    // Default "next step getter" just increments the current step by 1.
    let getNextStep = function() {
        return currentStep + 1;
    };

    let onSubmit = function() { console.log("Executing submit of step: " + currentStep) };


    useEffect(() => {
        if (containerRef.current && externalNode) {
            containerRef.current.appendChild(externalNode);
        }

        return () => {
            if (containerRef.current && externalNode && containerRef.current.contains(externalNode)) {
                containerRef.current.removeChild(externalNode);
            }
        };
    }, [externalNode]);

    if (!isOpen) return null;

    const isMultiStep = Children.count(children) > 1;
    const totalSteps = Children.count(children);
    const submitStep = 5;



    console.log("Current step:", currentStep);
    console.log("Total steps:", totalSteps);


    let nextAction = isMultiStep ?
        async (e) => {
            // Not sure we need this anymore ????
            let formData = new FormData(document.getElementById("batch-action"));
            //  && currentStep != submitStep (we can always do this later if we want to)
            await onSubmit(e);
            let theNextStep = getNextStep(formData);
            setCurrentStep(theNextStep);
        } :
        (e) => {
            onSubmit(e);
            // Also reset the steps to 0 or whatever?
        };



    return ReactDOM.createPortal(
        <div
            id="my-modal"
            aria-modal="true"
            role="dialog"
            onClick={onClose}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-900/40 backdrop-blur-sm"
        >
            <div
                onClick={(e) => e.stopPropagation()}
                className="relative max-w-[80vw] min-h-[360px] max-h-[85vh] flex flex-col bg-white rounded-2xl p-8 shadow-2xl overflow-hidden border border-gray-100"
            >


                {/* transition-transform duration-300 ease-in-out */}
                <div id="multi-step-container" className="overflow-x-hidden overflow-y-auto pr-2 flex-1 w-full">
                    {isMultiStep && (
                        <div
                            className="flex transition-transform duration-300 ease-in-out w-full"
                            style={{
                                width: `${totalSteps * 100}%`,
                                transform: `translateX(-${((currentStep - 1) / totalSteps) * 100}%)`
                            }}
                        >
                            {Children.map(children, (stepNode, index) => {

                                let step = index + 1;


                                let _getNextStep = stepNode.props.getNextStep;

                                if (step == currentStep && _getNextStep) {
                                    getNextStep = _getNextStep;
                                }
                                // We may not want to calculate whether to use the onSubmit by comparing step to totaleSteps
                                // we may want to use lastStep
                                if (step == currentStep && currentStep == submitStep && stepNode.props.onSubmit) {
                                    onSubmit = stepNode.props.onSubmit;
                                }

                                return (
                                    <div
                                        key={index}
                                        style={{ width: `${100 / totalSteps}%` }}
                                        className="flex flex-col items-center text-center space-y-6 px-4"
                                    >
                                        {isValidElement(stepNode) ? cloneElement(stepNode, { data: data, setData: setData }) : stepNode}
                                    </div>
                                );
                            })}
                        </div>
                    )}

                    {!isMultiStep && (
                        <div className="flex flex-col items-center text-center space-y-6">
                            {content}
                        </div>
                    )}

                    <div ref={containerRef} />
                </div>


                <div className="mt-6 pt-4 border-t border-gray-100 flex justify-end items-center">

                    {currentStep > 1 && (
                        <div className="mr-auto">
                            <BackButton label="< Back" action={() => setCurrentStep(currentStep - 1)} />
                        </div>
                    )}

                    <CautionButton label="Cancel" isCancel={true} action={onClose} />

                    {/* {currentStep == submitStep ? <input type="submit" value="Submit me" form="batch-action" /> : */}
                    <Button label={isMultiStep && currentStep != submitStep ? 'Next' : 'Confirm'} action={nextAction} />

                </div>

            </div>
        </div>,
        document.body
    );
}
